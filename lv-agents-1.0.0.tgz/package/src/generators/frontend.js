import fs from 'fs-extra';
import path from 'path';
import { execSync } from 'child_process';
import { buildFrontendAgent } from '../agents/frontend-agent.js';

// CSS tokens are neutral by default — update src/styles/tokens.css per project

export async function generateFrontend(config, rootDir) {
  const target = path.resolve(process.cwd(), `${config.projectName}-frontend`);
  await fs.ensureDir(target);
  // ── Folders ─────────────────────────────────────────────────────────────────
  const dirs = [
    'src/assets',
    'src/components/ui',
    'src/features',
    'src/layouts',
    // 'src/providers', // uncomment if you add ThemeProvider
    'src/pages',
    'src/hooks',
    'src/services',
    'src/store',
    'src/types',
    'src/utils',
    'src/styles',
    'tests',
    'docs/user-stories',
    'docs/api-contracts',
    'docs/design',
  ];
  for (const d of dirs) await fs.ensureDir(path.join(target, d));

  // ── Files ────────────────────────────────────────────────────────────────────
  const files = {
    'package.json':          packageJson(config),
    'vite.config.ts':        viteConfig(),
    'tsconfig.json':         tsConfig(),
    'tsconfig.app.json':     tsConfigApp(),
    'tailwind.config.ts':    tailwindConfig(),
    'postcss.config.js':     postcssConfig(),
    'index.html':            indexHtml(config.projectName),
    'src/main.tsx':          mainTsx(),
    'src/App.tsx':           appTsx(config),
    'src/styles/tokens.css': tokensCss(),
    'src/styles/globals.css': globalsCss(),
    'src/types/api.ts':      apiTypes(),
    'src/services/apiClient.ts': apiClient(config),
    'src/utils/cn.ts':       cnUtil(),
    'src/utils/logger.ts':   logger(),
    'src/store/authStore.ts': authStore(),
    // ThemeProvider: add manually if your project needs dynamic theming from backend
    'src/layouts/PublicLayout.tsx':  publicLayout(),
    'src/layouts/AuthLayout.tsx':    authLayout(),
    'src/layouts/AdminLayout.tsx':   adminLayout(),
    'src/pages/HomePage.tsx':        homePage(),
    'src/components/ui/Button.tsx':  button(),
    'src/components/ui/Button.test.tsx': buttonTest(),
    'tests/setup.ts':        testSetup(),
    '.gitignore':            gitignore(),
    '.env.example':          envExample(),
    'docs/README.md':        docsReadme(config.projectName),
    'docs/design-brief.md':  designBrief(config),
    'docs/user-stories/US-002-example.md': exampleStory(),
    'README.md':             readme(config),
  };

  // Claude Code custom commands
  const claudeCmd = t => t;
  files['.claude/commands/frontend.md']   = claudeCmd('Generate frontend code following agent rules.\n\nUsage: /frontend <task>\n\nRules: TypeScript strict, CSS variables only (no hardcoded hex), Radix UI for interactive components, motion for animations, sonner for toasts, cn() for classes, cva for variants, lucide-react for icons. Deliver: component + hook + test + file list.');
  files['.claude/commands/component.md']  = claudeCmd('Generate a complete UI component.\n\nUsage: /component <Name>\n\nDeliver: 1) Component.tsx with TypeScript props interface 2) cva variants if visual states exist 3) cn() for classes 4) Component.test.tsx with render/loading/error tests 5) New types in src/types/api.ts if needed.');
  files['.claude/commands/feature.md']    = claudeCmd('Generate a complete feature module.\n\nUsage: /feature <name>\n\nDeliver: 1) src/features/<name>/components/ 2) src/features/<name>/hooks/ with useQuery/useMutation 3) src/features/<name>/types/ 4) Page in src/pages/ 5) Route in App.tsx.');
  files['.claude/commands/hook.md']       = claudeCmd('Generate a custom React hook.\n\nUsage: /hook <name>\n\nRules: useQuery for reads (never useEffect+useState for fetching), useMutation for writes, all HTTP through apiClient.ts. Include loading, error, success states.');
  files['.claude/commands/form.md']       = claudeCmd('Generate a validated form component.\n\nUsage: /form <Name>\n\nDeliver: 1) Form.tsx with React Hook Form + Zod 2) Inline field errors with role=alert 3) Submit button with Loader2 spinner 4) useMutation for submit 5) sonner toast on success/error.');
  files['.claude/commands/docs.md']       = claudeCmd('Read user stories from docs/user-stories/ and build a work queue.\n\nUsage: /docs\n\nSteps: 1) Ask for docs/user-stories/ content 2) Parse frontmatter 3) Filter layer=frontend or both 4) Sort high to low priority 5) Confirm queue before starting.');

  // ── UX/UI design-director commands ───────────────────────────────────────────
  files['.claude/commands/design.md'] = claudeCmd(designCmd());
  files['.claude/commands/palette.md'] = claudeCmd(paletteCmd());
  files['.claude/commands/ux.md'] = claudeCmd(uxCmd());

  // Agent files
  const agentContent = buildFrontendAgent(config);
  if (config.aiTools.includes('cursor')) files['.cursorrules'] = agentContent;
  if (config.aiTools.includes('claude')) files['CLAUDE.md'] = agentContent;

  for (const [p, c] of Object.entries(files)) {
    await fs.outputFile(path.join(target, p), c, 'utf8');
  }

  // ── Install UX/UI skills ─────────────────────────────────────────────────────
  const skills = [
    {
      cmd:    'npx skills add emilkowalski/skill',
      label:  'emilkowalski',
      desc:   'Animations, interactions, accessibility (sonner, vaul, motion patterns)',
      verify: '.agents/skills/emil-design-eng/SKILL.md',
    },
    {
      cmd:    'npx impeccable skills install --yes',
      label:  'impeccable',
      desc:   'Spacing system, visual hierarchy, layout consistency + anti-pattern detector',
      verify: '.agents/skills/impeccable/SKILL.md',
    },
    {
      cmd:    'npx skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"',
      label:  'design-taste-frontend',
      desc:   'Aesthetic refinement, color calibration, form/contrast rules',
      verify: '.agents/skills/design-taste-frontend/SKILL.md',
    },
  ];

  const skillResults = [];

  for (const skill of skills) {
    try {
      execSync(skill.cmd, { cwd: target, stdio: 'pipe', timeout: 30000 });
      skillResults.push({ ...skill, installed: true });
    } catch {
      skillResults.push({ ...skill, installed: false });
    }
  }

  // Write SKILLS.md at project root — always, regardless of install result.
  // Status markers reflect the ACTUAL install result; verify paths let the
  // agent confirm on disk (never trust the checkmarks alone).
  const skillsLines = [
    '# UX/UI Skills',
    '',
    'These skills define the design rules for this project.',
    'Agents read them from `.agents/skills/` (and `.claude/skills/` for impeccable).',
    '',
    '> Verification rule: a skill is installed ONLY if its SKILL.md exists on disk.',
    '> Do not trust the checkmarks below without checking the paths.',
    '',
    '## Status',
    '',
    ...skillResults.map(s => [
      `### ${s.label} ${s.installed ? '✓ installed' : '⚠ needs manual install'}`,
      s.desc,
      `Verify: \`${s.verify}\``,
      '',
      '```bash',
      s.cmd,
      '```',
      '',
      ...(s.label === 'impeccable' ? [
        "Windows: if it fails with `'unzip' is not recognized`, add an `unzip.cmd` shim",
        'on PATH that runs `tar -xf %2 -C %4` (create %4 first), then retry.',
        '',
        'Quality gate after building UI:',
        '',
        '```bash',
        'npx impeccable detect src/',
        '```',
        '',
      ] : []),
    ].join('\n')),
    '## How to install manually',
    '',
    'Run from the project root:',
    '',
    '```bash',
    'node install-skills.js',
    '```',
  ].join('\n');

  await fs.outputFile(path.join(target, 'SKILLS.md'), skillsLines, 'utf8');

  // Also write install script for convenience
  const installScript = `#!/usr/bin/env node
// Install all UX/UI skills — works on Windows, Mac and Linux
// Usage: node install-skills.js
import { execSync } from 'child_process';
import { existsSync } from 'fs';

const skills = [
  { cmd: 'npx skills add emilkowalski/skill',           label: 'emilkowalski',          verify: '.agents/skills/emil-design-eng/SKILL.md' },
  { cmd: 'npx impeccable skills install --yes',         label: 'impeccable',            verify: '.agents/skills/impeccable/SKILL.md' },
  { cmd: 'npx skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"', label: 'design-taste-frontend', verify: '.agents/skills/design-taste-frontend/SKILL.md' },
];

const results = [];
for (const skill of skills) {
  console.log('Installing:', skill.label, '...');
  try {
    execSync(skill.cmd, { stdio: 'inherit' });
  } catch {
    console.error('  command failed for', skill.label);
    if (skill.label === 'impeccable' && process.platform === 'win32') {
      console.error("  Windows: if the error mentions 'unzip', put an unzip.cmd shim on PATH");
      console.error('  that runs:  tar -xf %2 -C %4   (create %4 first), then retry.');
    }
  }
  // Verification rule: a skill counts as installed ONLY if its SKILL.md is on disk
  const ok = existsSync(skill.verify);
  results.push({ ...skill, ok });
  console.log(ok
    ? '\\u2713 ' + skill.label + ' (' + skill.verify + ')'
    : '\\u2717 ' + skill.label + ' — SKILL.md not found, run manually: ' + skill.cmd);
}

const missing = results.filter(r => !r.ok);
console.log('\\n' + (results.length - missing.length) + '/' + results.length + ' skills verified on disk. See SKILLS.md.');
for (const m of missing) console.log('  missing: ' + m.label + ' -> ' + m.cmd);
`;

  await fs.outputFile(path.join(target, 'install-skills.js'), installScript, 'utf8');
}

// ── File builders ─────────────────────────────────────────────────────────────
const claudeCmd = text => text;

// ── UX/UI design-director command prompts ──────────────────────────────────────
const designCmd = () => `UX/UI Design Director. Turn the business brief into a design system. Do NOT write feature/component code here.

Usage: /design [extra context]
The business is described in docs/design-brief.md — READ IT FIRST. Any argument refines it.
Examples: /design · /design lean more premium and dark · /design audience is families with kids

Step 0 — Inputs: read docs/design-brief.md and the installed skills (verify each SKILL.md on disk):
- design-taste-frontend  — color calibration, form and contrast rules
- impeccable             — spacing scale, visual hierarchy, layout
- emilkowalski           — motion, interaction, accessibility
If the brief is empty, ask the user what the site is for before proposing anything.

Step 1 — PROPOSE (do not write files yet): present 2-3 DISTINCT directions tailored to the business. For each direction give:
- Personality — 3-5 adjectives inferred from the domain (e.g. vivero -> natural, calm, organic; premium dealership -> bold, precise, aspirational).
- Accent + neutral base — hex values, WCAG AA verified (>=4.5:1 for text); state the ratio.
- Typography — heading/body pairing.
- Button style — shape, weight, motion feel.
- One-line rationale linking it to the business.

Step 2 — WAIT for the user to choose or adjust a direction. Never skip this confirmation.

Step 3 — After confirmation, WRITE:
- docs/design/design-system.md — the chosen system: full palette, type scale, spacing (impeccable), button/component specs (cva variants primary/secondary/ghost/danger with hover/focus/active/disabled), motion patterns (emil), 2-3 signature domain UX moves, and accessibility notes.
- src/styles/tokens.css — the chosen tokens, both :root and [data-theme="dark"]: brand accent in --primary-color, neutral grays, and semantic colors kept separate (red=error, emerald=success, amber=warning, blue=info).

Hard rules: CSS variables only — ALL color lives in tokens.css, never hardcoded hex in components. Interactive elements use Radix + cn() + cva. Icons via lucide-react. Recoloring the whole app must be a tokens.css-only change.

End by offering: "Run /palette to refine the tokens, /ux <screen> for a specific flow, or /feature <name> to build with this direction."`;

const paletteCmd = () => `Color System Specialist. Propose and lock the project's color tokens for a given domain, brand or vibe.

Usage: /palette <domain, brand or vibe>
Examples: /palette eco-friendly plant nursery · /palette luxury dealership, dark-first · /palette fintech, trustworthy blue

Follow design-taste-frontend's color calibration. Steps:
1. Infer the palette personality from the input and pick a domain-appropriate accent.
2. Build: a neutral gray scale (bg, surface, borders, text) + EXACTLY ONE brand accent in --primary-color (--accent-color may be a tint/shade of it). Keep semantic colors separate: red=error, emerald=success, amber=warning, blue=info.
3. Verify every text/background pair meets WCAG AA (>=4.5:1) and state the ratios.
4. Output the COMPLETE src/styles/tokens.css (both :root and [data-theme="dark"]) ready to paste — recoloring must be a tokens.css-only change.
5. Usage note: map each token to its Tailwind class (text-primary, bg-primary, surface) so components stay hex-free.

If the user gives no domain, suggest 2-3 AA-verified starting points (e.g. emerald #059669, electric blue #2563eb, terracotta #c2410c) and ask which fits before committing. Never scatter hex values inside components.`;

const uxCmd = () => `UX Reviewer & Advisor. Recommend the optimal user experience for a screen, flow or requirement — grounded in the project domain and the installed skills. This is advice + a plan, not code.

Usage: /ux <screen, flow or requirement>
Examples: /ux checkout for a plant nursery · /ux car comparison page · /ux onboarding for first-time users

If the request maps to a story in docs/user-stories/, read it first. Deliver:
1. User & intent — who uses this, what they want to accomplish; primary vs secondary actions.
2. Information architecture — layout, visual hierarchy (impeccable), what leads vs what is secondary; empty / loading / error / success states.
3. Interaction design — key flows step by step; which Radix primitives to use; feedback and motion (emil: toasts via sonner, drawers/sheets via vaul, enter/exit via AnimatePresence).
4. Domain-specific recommendations — patterns that fit this vertical (e.g. vivero: care reminders, seasonal badges; dealership: financing CTA, comparison table, test-drive booking).
5. Accessibility — keyboard flow, ARIA, contrast, focus management, reduced-motion.
6. Pitfalls to avoid for this domain.

End by offering /feature or /form to implement the recommendation.`;

const packageJson = config => JSON.stringify({
  name: `${config.projectName}-frontend`,
  private: true,
  version: '0.1.0',
  type: 'module',
  scripts: {
    dev: 'vite',
    build: 'tsc -b && vite build',
    preview: 'vite preview',
    test: 'vitest',
    'test:coverage': 'vitest run --coverage',
  },
  dependencies: {
    react: '^18.3.1', 'react-dom': '^18.3.1',
    'react-router-dom': '^6.26.0',
    '@tanstack/react-query': '^5.56.0',
    axios: '^1.7.7',
    zustand: '^5.0.0',
    'react-hook-form': '^7.53.0',
    zod: '^3.23.8',
    '@hookform/resolvers': '^3.9.0',
    sonner: '^1.5.0', vaul: '^0.9.0', motion: '^11.3.0',
    '@radix-ui/react-dialog': '^1.1.0',
    '@radix-ui/react-dropdown-menu': '^2.1.0',
    '@radix-ui/react-select': '^2.1.0',
    '@radix-ui/react-tooltip': '^1.1.0',
    '@radix-ui/react-tabs': '^1.1.0',
    '@radix-ui/react-avatar': '^1.1.0',
    '@radix-ui/react-switch': '^1.1.0',
    '@radix-ui/react-popover': '^1.1.0',
    'class-variance-authority': '^0.7.0',
    clsx: '^2.1.0', 'tailwind-merge': '^2.4.0',
    'lucide-react': '^0.400.0',
  },
  devDependencies: {
    '@types/react': '^18.3.5', '@types/react-dom': '^18.3.0',
    '@vitejs/plugin-react': '^4.3.1',
    typescript: '^5.5.3', vite: '^5.4.2',
    tailwindcss: '^3.4.10', autoprefixer: '^10.4.20', postcss: '^8.4.45',
    vitest: '^2.0.5', '@vitest/ui': '^2.0.5',
    '@testing-library/react': '^16.0.1',
    '@testing-library/jest-dom': '^6.5.0',
    '@testing-library/user-event': '^14.5.2',
    jsdom: '^25.0.0',
  },
}, null, 2);

const viteConfig = () => `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  server: { port: 5173 },
  test: { globals: true, environment: 'jsdom', setupFiles: ['./tests/setup.ts'] },
})`;

const tsConfig = () => JSON.stringify({ files: [], references: [{ path: './tsconfig.app.json' }] }, null, 2);

const tsConfigApp = () => JSON.stringify({
  compilerOptions: {
    target: 'ES2020', useDefineForClassFields: true,
    lib: ['ES2020', 'DOM', 'DOM.Iterable'],
    module: 'ESNext', skipLibCheck: true,
    moduleResolution: 'bundler', allowImportingTsExtensions: true,
    isolatedModules: true, moduleDetection: 'force', noEmit: true,
    jsx: 'react-jsx', strict: true,
    noUnusedLocals: true, noUnusedParameters: true,
    baseUrl: '.', paths: { '@/*': ['./src/*'] },
  },
  include: ['src'],
}, null, 2);

const tailwindConfig = () => `import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        primary: 'var(--primary-color)',
        accent:  'var(--accent-color)',
        surface: 'var(--surface-color)',
      },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
}

export default config`;

const postcssConfig = () => `export default { plugins: { tailwindcss: {}, autoprefixer: {} } }`;

const indexHtml = name => `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${name}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`;

const mainTsx = () => `import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from './App.tsx'
import './styles/tokens.css'
import './styles/globals.css'

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 1000 * 60 * 5 } },
})

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>,
)`;

const appTsx = config => `import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { Toaster } from 'sonner'
import PublicLayout from '@/layouts/PublicLayout'
import AuthLayout from '@/layouts/AuthLayout'
import AdminLayout from '@/layouts/AdminLayout'
import HomePage from '@/pages/HomePage'

const router = createBrowserRouter([
  {
    element: <PublicLayout />,
    children: [{ path: '/', element: <HomePage /> }],
  },
  {
    path: '/admin/login',
    element: <AuthLayout />,
    children: [
      // { index: true, element: <LoginPage /> },
    ],
  },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: [
      // { index: true, element: <DashboardPage /> },
    ],
  },
])

export default function App() {
  return (
    <>
      <RouterProvider router={router} />
      <Toaster position="top-right" richColors />
    </>
  )
}`;

const tokensCss = () => `:root {
  --primary-color: #6b7280;
  --accent-color:  #374151;
  --bg-color:      #f9fafb;
  --surface-color: #ffffff;

  --spacing-xs: 4px;  --spacing-sm: 8px;
  --spacing-md: 16px; --spacing-lg: 24px;
  --spacing-xl: 32px; --spacing-2xl: 48px;

  --radius-sm: 4px; --radius-md: 8px; --radius-lg: 12px;
  --font-sans: 'Inter', system-ui, sans-serif;
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
  --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
}

[data-theme="dark"] {
  --bg-color:      #0f172a;
  --surface-color: #1e293b;
}`;

const globalsCss = () => `@tailwind base;
@tailwind components;
@tailwind utilities;

*, *::before, *::after { box-sizing: border-box; }
body { font-family: var(--font-sans); background-color: var(--bg-color); margin: 0; }`;

const apiTypes = () => `/**
 * All DTOs must mirror backend contracts exactly.
 * Update this file when backend DTOs change.
 */

export interface ApiError { status: number; title: string; detail: string }

export interface PaginatedResponse<T> {
  items: T[]; total: number; page: number; pageSize: number;
}`;

const apiClient = config => `import axios, { type AxiosError, type InternalAxiosRequestConfig } from 'axios'

/**
 * Centralized HTTP client.
 * - Attaches JWT automatically
 * - Handles 401 → clears auth + redirect
 * - Normalizes errors to ApiError
 */
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
})

apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = \`Bearer \${token}\`
  return config
})

apiClient.interceptors.response.use(
  res => res,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      window.location.href = '/admin/login'
    }
    return Promise.reject(error)
  }
)

export default apiClient`;

const cnUtil = () => `import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

/**
 * Combines Tailwind classes safely, resolving conflicts.
 * Use in ALL components instead of string concatenation.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}`;

const logger = () => `const isDev = import.meta.env.DEV

export const logger = {
  info:  (...args: unknown[]) => { if (isDev) console.info('[INFO]', ...args) },
  warn:  (...args: unknown[]) => { if (isDev) console.warn('[WARN]', ...args) },
  error: (...args: unknown[]) => console.error('[ERROR]', ...args),
}`;

const authStore = () => `import { create } from 'zustand'

interface AuthState {
  token: string | null
  isAuthenticated: boolean
  setAuth: (token: string, expiresAt: string) => void
  clearAuth: () => void
}

export const useAuthStore = create<AuthState>(set => ({
  token: localStorage.getItem('access_token'),
  isAuthenticated: !!localStorage.getItem('access_token'),
  setAuth: (token) => {
    localStorage.setItem('access_token', token)
    set({ token, isAuthenticated: true })
  },
  clearAuth: () => {
    localStorage.removeItem('access_token')
    set({ token: null, isAuthenticated: false })
  },
}))`;

const themeProvider = () => `import { createContext, useContext, useEffect, type ReactNode } from 'react'
import { useQuery } from '@tanstack/react-query'
import apiClient from '@/services/apiClient'

interface ThemeConfig {
  primaryColor: string; accentColor: string
  backgroundColor: string; surfaceColor: string
  fontFamily: string; borderRadius: string
}

const ThemeContext = createContext<ThemeConfig | null>(null)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { data: theme } = useQuery<ThemeConfig>({
    queryKey: ['theme'],
    queryFn: () => apiClient.get('/theme').then(r => r.data),
    staleTime: Infinity,
    retry: false,
  })

  useEffect(() => {
    if (!theme) return
    const r = document.documentElement
    r.style.setProperty('--primary-color', theme.primaryColor)
    r.style.setProperty('--accent-color',  theme.accentColor)
    r.style.setProperty('--bg-color',      theme.backgroundColor)
    r.style.setProperty('--surface-color', theme.surfaceColor)
    r.style.setProperty('--font-family',   theme.fontFamily)
    r.style.setProperty('--border-radius', theme.borderRadius)
  }, [theme])

  return <ThemeContext.Provider value={theme ?? null}>{children}</ThemeContext.Provider>
}

export const useTheme = () => useContext(ThemeContext)`;

const publicLayout  = () => `import { Outlet } from 'react-router-dom'\n\nexport default function PublicLayout() {\n  return (\n    <div className="min-h-screen flex flex-col">\n      <header className="border-b px-6 py-4">\n        <nav className="max-w-7xl mx-auto flex items-center justify-between">\n          <span className="font-semibold text-primary">My Project</span>\n        </nav>\n      </header>\n      <main className="flex-1"><Outlet /></main>\n      <footer className="border-t px-6 py-4 text-center text-sm text-gray-500">\n        © {new Date().getFullYear()}\n      </footer>\n    </div>\n  )\n}`;
const authLayout    = () => `import { Outlet } from 'react-router-dom'\n\nexport default function AuthLayout() {\n  return (\n    <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg-color)' }}>\n      <div className="w-full max-w-md px-4"><Outlet /></div>\n    </div>\n  )\n}`;
const adminLayout   = () => `import { Outlet } from 'react-router-dom'\n\nexport default function AdminLayout() {\n  return (\n    <div className="min-h-screen flex">\n      <aside className="w-64 border-r flex flex-col">\n        <div className="p-6 font-semibold text-primary">Admin</div>\n      </aside>\n      <div className="flex-1 flex flex-col">\n        <header className="border-b px-6 py-4" />\n        <main className="flex-1 p-6"><Outlet /></main>\n      </div>\n    </div>\n  )\n}`;
const homePage      = () => `export default function HomePage() {\n  return (\n    <div className="max-w-7xl mx-auto px-6 py-12">\n      <h1 className="text-2xl font-semibold">Welcome</h1>\n      <p className="mt-2 text-gray-600">Project generated with ga-agents.</p>\n    </div>\n  )\n}`;

const button = () => `import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { Loader2 } from 'lucide-react'
import { cn } from '@/utils/cn'

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 rounded-[var(--radius-md)] font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-50 disabled:cursor-not-allowed',
  {
    variants: {
      variant: {
        primary:   'bg-primary text-white hover:opacity-90',
        secondary: 'border border-primary text-primary hover:bg-primary/10',
        ghost:     'text-gray-600 hover:bg-gray-100',
        danger:    'bg-red-600 text-white hover:bg-red-700',
      },
      size: { sm: 'px-3 py-1.5 text-sm', md: 'px-4 py-2', lg: 'px-6 py-3 text-lg' },
    },
    defaultVariants: { variant: 'primary', size: 'md' },
  }
)

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  isLoading?: boolean
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant, size, isLoading, children, disabled, className, ...props }, ref) => (
    <button ref={ref} disabled={disabled || isLoading}
      className={cn(buttonVariants({ variant, size }), className)} {...props}>
      {isLoading && <Loader2 size={16} className="animate-spin" aria-hidden="true" />}
      {children}
    </button>
  )
)
Button.displayName = 'Button'
export default Button`;

const buttonTest = () => `import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Button from './Button'

describe('Button', () => {
  it('renders text', () => {
    render(<Button>Save</Button>)
    expect(screen.getByRole('button', { name: 'Save' })).toBeInTheDocument()
  })
  it('calls onClick', async () => {
    const fn = vi.fn()
    render(<Button onClick={fn}>Click</Button>)
    await userEvent.click(screen.getByRole('button'))
    expect(fn).toHaveBeenCalledTimes(1)
  })
  it('is disabled when isLoading', () => {
    render(<Button isLoading>Loading</Button>)
    expect(screen.getByRole('button')).toBeDisabled()
  })
})`;

const testSetup  = () => `import '@testing-library/jest-dom'`;
const gitignore  = () => `node_modules/\ndist/\n.env\n.env.local\n*.local`;
const envExample = () => `VITE_API_BASE_URL=http://localhost:5000/api`;

const designBrief = config => `# Design Brief — ${config.projectName}-frontend

> Captured at project creation. This is the source of truth for the UX/UI
> direction. Run \`/design\` in the agent to turn it into a design system.

## Business / what the site is for

${config.businessDescription?.trim() || '_Not provided at setup — describe the business here, then run /design._'}

## How the agent uses this

1. \`/design\` reads this brief + the installed skills (see SKILLS.md) and
   proposes 2-3 palette + design directions tailored to the business.
2. After you confirm one, the agent writes \`docs/design/design-system.md\`
   and updates \`src/styles/tokens.css\` with the chosen tokens.
3. \`/palette\` can re-lock or refine the color tokens at any time.

## Notes to refine (optional)

- Target audience:
- Tone / personality (e.g. playful, premium, trustworthy):
- Brand color if any:
- References / competitors you like:
`;

const docsReadme = name => `# docs — ${name}-frontend

This folder is the **source of truth** for the frontend agent.

## Adding a user story

Create a \`.md\` file in \`user-stories/\` then run:

\`\`\`bash
npx agent-docs
\`\`\`
`;

const exampleStory = () => `---
id: US-002
title: Login form
layer: frontend
priority: high
status: pending
---

# US-002 — Login form

**As** a registered admin
**I want** to log in with email and password
**So that** I can access the admin panel

## Acceptance criteria

- [ ] Form has \`email\` and \`password\` fields validated with Zod
- [ ] Shows inline errors on blur
- [ ] Button shows spinner while request is pending
- [ ] On success: stores JWT in authStore, redirects to /admin/dashboard
- [ ] On error: shows toast with error detail
`;

const readme = config => `# ${config.projectName}-frontend

Generated by **lv-agents** — React 18 + Vite + TypeScript.

## Quick start

\`\`\`bash
npm install
cp .env.example .env
npm run dev
\`\`\`

## Agent

${config.aiTools.includes('cursor') ? '- **Cursor**: open this folder — `.cursorrules` activates automatically' : ''}
${config.aiTools.includes('claude') ? '- **Claude Projects**: paste `CLAUDE.md` into Project Instructions' : ''}

## User stories

Add \`.md\` files to \`docs/user-stories/\` and run:

\`\`\`bash
npx agent-docs
\`\`\`
`;
