import fs from 'fs-extra';
import path from 'path';
import { buildBackendAgent } from '../agents/backend-agent.js';

export async function generateBackend(config, rootDir) {
  const target = path.resolve(process.cwd(), `${config.projectName}-backend`);
  await fs.ensureDir(target);
  const N = toPascal(config.projectName);

  // ── Folder structure ────────────────────────────────────────────────────────
  const dirs = [
    `src/${N}.Domain/Entities`,
    `src/${N}.Domain/Interfaces`,
    `src/${N}.Domain/ValueObjects`,
    `src/${N}.Domain/Exceptions`,
    `src/${N}.Application/UseCases`,
    `src/${N}.Application/DTOs`,
    `src/${N}.Application/Interfaces`,
    `src/${N}.Application/Validators`,
    `src/${N}.Infrastructure/Persistence`,
    `src/${N}.Infrastructure/Repositories`,
    `src/${N}.Infrastructure/Services`,
    `src/${N}.API/Endpoints`,
    `src/${N}.API/Middleware`,
    `tests/${N}.UnitTests`,
    `tests/${N}.IntegrationTests`,
    `docs/user-stories`,
    `docs/api-contracts`,
  ];
  for (const d of dirs) await fs.ensureDir(path.join(target, d));

  // ── Files ───────────────────────────────────────────────────────────────────
  const files = {
    // Domain
    [`src/${N}.Domain/${N}.Domain.csproj`]: domainCsproj(N),
    [`src/${N}.Domain/Entities/BaseEntity.cs`]: baseEntity(N),
    [`src/${N}.Domain/Interfaces/IRepository.cs`]: iRepository(N),
    [`src/${N}.Domain/Exceptions/DomainException.cs`]: domainExceptions(N),

    // Application
    [`src/${N}.Application/${N}.Application.csproj`]: appCsproj(N),
    [`src/${N}.Application/Interfaces/IUnitOfWork.cs`]: iUnitOfWork(N),

    // Infrastructure
    [`src/${N}.Infrastructure/${N}.Infrastructure.csproj`]: infraCsproj(N, config),
    [`src/${N}.Infrastructure/Persistence/AppDbContext.cs`]: dbContext(N, config),

    // API
    [`src/${N}.API/${N}.API.csproj`]: apiCsproj(N),
    [`src/${N}.API/Program.cs`]: program(N, config),
    [`src/${N}.API/appsettings.json`]: appSettings(config),
    [`src/${N}.API/appsettings.Development.json`]: appSettingsDev(config),
    [`src/${N}.API/Middleware/ExceptionMiddleware.cs`]: exceptionMiddleware(N),

    // Docs
    'docs/README.md': docsReadme(config.projectName),
    'docs/user-stories/US-001-example.md': exampleStory(),

    // Git
    '.gitignore': gitignore(),
    'README.md': readme(config, N),

    // Claude Code custom commands
    '.claude/commands/backend.md':    claudeCmd('Generate backend code following Clean Architecture rules.\n\nUsage: /backend <task>\n\nAlways implement all four layers: Domain, Application, Infrastructure, API. Use Minimal APIs. Return IResult via Results.*. All errors through ExceptionMiddleware. Deliver entity + interface + use case + DTO + validator + repository + endpoint. End with a checklist of every file created.'),
    '.claude/commands/domain.md':     claudeCmd('Generate the complete Domain layer for an entity.\n\nUsage: /domain <EntityName>\n\nDeliver: 1) Entity with private setters in Domain/Entities/ 2) IRepository interface in Domain/Interfaces/ 3) Value Objects if needed 4) Domain exceptions if new rules apply.'),
    '.claude/commands/usecase.md':    claudeCmd('Generate a Command or Query use case.\n\nUsage: /usecase <Name>\n\nDeliver: 1) Command/Query record in Application/UseCases/ 2) Handler class 3) Input and Output DTOs 4) FluentValidation validator.'),
    '.claude/commands/endpoint.md':   claudeCmd('Generate a Minimal API endpoint.\n\nUsage: /endpoint <METHOD> <route>\n\nDeliver: 1) Endpoint using Results.* 2) Route group registration 3) Authorization if protected 4) Program.cs addition.'),
    '.claude/commands/repository.md': claudeCmd('Generate repository interface and implementation.\n\nUsage: /repository <EntityName>\n\nDeliver: 1) IEntityRepository in Domain/Interfaces/ (no EF/Mongo refs) 2) Concrete implementation in Infrastructure/Repositories/ 3) DI registration.'),
    '.claude/commands/docs.md':       claudeCmd('Read user stories from docs/user-stories/ and build a prioritized work queue.\n\nUsage: /docs\n\nSteps: 1) Ask user to paste docs/user-stories/ content 2) Parse frontmatter 3) Filter layer=backend or both 4) Sort high→medium→low 5) Confirm queue before starting.'),
  };

  // Agent files
  const agentContent = buildBackendAgent(config);
  if (config.aiTools.includes('cursor')) files['.cursorrules'] = agentContent;
  if (config.aiTools.includes('claude')) files['CLAUDE.md'] = agentContent;

  for (const [p, c] of Object.entries(files)) {
    await fs.outputFile(path.join(target, p), c, 'utf8');
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const toPascal = s => s.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join('');
const claudeCmd = text => text;

const domainCsproj = N => `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
</Project>`;

const appCsproj = N => `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\\${N}.Domain\\${N}.Domain.csproj" />
  </ItemGroup>
  <ItemGroup>
    <PackageReference Include="FluentValidation" Version="11.10.0" />
  </ItemGroup>
</Project>`;

const infraCsproj = (N, config) => `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\\${N}.Application\\${N}.Application.csproj" />
    <ProjectReference Include="..\\${N}.Domain\\${N}.Domain.csproj" />
  </ItemGroup>
  <ItemGroup>
    <!-- Add your database provider here:                                    -->
    <!-- EF Core + SQL Server:  Microsoft.EntityFrameworkCore.SqlServer      -->
    <!-- EF Core + PostgreSQL:  Npgsql.EntityFrameworkCore.PostgreSQL        -->
    <!-- MongoDB:               MongoDB.Driver                               -->
    <!-- <PackageReference Include="Microsoft.EntityFrameworkCore" Version="10.0.0" /> -->
  </ItemGroup>
</Project>`;

const apiCsproj = N => `<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\\${N}.Application\\${N}.Application.csproj" />
    <ProjectReference Include="..\\${N}.Infrastructure\\${N}.Infrastructure.csproj" />
  </ItemGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="10.0.0" />
    <PackageReference Include="Microsoft.AspNetCore.Identity.EntityFrameworkCore" Version="10.0.0" />
    <PackageReference Include="Swashbuckle.AspNetCore" Version="7.0.0" />
  </ItemGroup>
</Project>`;

const baseEntity = N => `namespace ${N}.Domain.Entities;

/// <summary>Base entity with identity and audit fields.</summary>
public abstract class BaseEntity
{
    public Guid Id { get; protected set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; protected set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; protected set; }
    protected void SetUpdated() => UpdatedAt = DateTime.UtcNow;
}`;

const iRepository = N => `namespace ${N}.Domain.Interfaces;

/// <summary>
/// Generic repository contract. Concrete implementations live in Infrastructure.
/// No references to EF Core, MongoDB, or any provider.
/// </summary>
public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IEnumerable<T>> GetAllAsync(CancellationToken ct = default);
    Task AddAsync(T entity, CancellationToken ct = default);
    Task UpdateAsync(T entity, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}`;

const domainExceptions = N => `namespace ${N}.Domain.Exceptions;

/// <summary>Base exception for domain business rule violations.</summary>
public class DomainException(string message) : Exception(message);

/// <summary>Requested resource was not found.</summary>
public class NotFoundException(string entity, object key)
    : DomainException($"{entity} with key '{key}' was not found.");

/// <summary>A business rule was violated.</summary>
public class BusinessRuleException(string rule)
    : DomainException($"Business rule violated: {rule}");`;

const iUnitOfWork = N => `namespace ${N}.Application.Interfaces;

/// <summary>Coordinates multiple repositories within a single transaction.</summary>
public interface IUnitOfWork : IAsyncDisposable
{
    Task<int> SaveChangesAsync(CancellationToken ct = default);
    Task BeginTransactionAsync(CancellationToken ct = default);
    Task CommitAsync(CancellationToken ct = default);
    Task RollbackAsync(CancellationToken ct = default);
}`;

const dbContext = (N, config) => `using Microsoft.EntityFrameworkCore;

namespace ${N}.Infrastructure.Persistence;

/// <summary>
/// Main DbContext. Add your DbSet<TEntity> properties here.
/// Entity configurations live in separate IEntityTypeConfiguration<T> classes.
/// Connection string is read from IConfiguration["ConnectionStrings:Default"].
///
/// To switch to MongoDB: replace this file with MongoDbContext using MongoDB.Driver.
/// Connection string keys: MongoDB:ConnectionString and MongoDB:DatabaseName.
/// </summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    // Add your DbSets here:
    // public DbSet<User> Users => Set<User>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }
}`;

const program = (N, config) => `using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using ${N}.API.Middleware;

var builder = WebApplication.CreateBuilder(args);

// ── Database ──────────────────────────────────────────────────────────────────
// Uncomment and configure your DB provider:
// builder.Services.AddDbContext<AppDbContext>(opt =>
//     opt.UseSqlServer(builder.Configuration.GetConnectionString("Default")));
// builder.Services.AddDbContext<AppDbContext>(opt =>
//     opt.UseNpgsql(builder.Configuration.GetConnectionString("Default")));
// builder.Services.AddSingleton<MongoDbContext>();

// ── Authentication (JWT) ──────────────────────────────────────────────────────
// Uncomment to enable JWT authentication:
// var jwtKey = builder.Configuration["Jwt:SecretKey"]
//     ?? throw new InvalidOperationException("Jwt:SecretKey not configured.");
// builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//     .AddJwtBearer(opt =>
//     {
//         opt.TokenValidationParameters = new TokenValidationParameters
//         {
//             ValidateIssuer           = true,
//             ValidateAudience         = true,
//             ValidateLifetime         = true,
//             ValidateIssuerSigningKey = true,
//             ValidIssuer              = builder.Configuration["Jwt:Issuer"],
//             ValidAudience            = builder.Configuration["Jwt:Audience"],
//             IssuerSigningKey         = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
//         };
//     });
// builder.Services.AddAuthorization(opt =>
//     opt.AddPolicy("AdminOnly", p => p.RequireRole("Admin")));

// ── OpenAPI ───────────────────────────────────────────────────────────────────
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ── DI registrations ──────────────────────────────────────────────────────────
// Register your repositories and services here:
// builder.Services.AddScoped<IUserRepository, UserRepository>();

var app = builder.Build();

// ── Middleware ────────────────────────────────────────────────────────────────
app.UseMiddleware<ExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
// app.UseAuthentication();
// app.UseAuthorization();

// ── Endpoints ─────────────────────────────────────────────────────────────────
// Map your endpoint groups here:
// app.MapGroup("/api/auth").MapAuthEndpoints();

app.Run();`;

const appSettings = config => JSON.stringify({
  Logging: { LogLevel: { Default: 'Information', 'Microsoft.AspNetCore': 'Warning' } },
  AllowedHosts: '*',
  ConnectionStrings: { Default: 'REPLACE_WITH_YOUR_CONNECTION_STRING' },
  Jwt: {
    SecretKey: 'REPLACE_WITH_SECURE_SECRET_MIN_32_CHARS',
    Issuer: `${config.projectName}-api`,
    Audience: `${config.projectName}-client`,
    ExpirationMinutes: 60,
  },
}, null, 2);

const appSettingsDev = config => JSON.stringify({
  Logging: { LogLevel: { Default: 'Debug', 'Microsoft.AspNetCore': 'Information' } },
  ConnectionStrings: { Default: `Host=localhost;Port=5432;Database=${config.projectName};Username=postgres;Password=postgres` },
  Jwt: {
    SecretKey: 'dev-secret-key-minimum-32-characters!!',
    Issuer: `${config.projectName}-api`,
    Audience: `${config.projectName}-client`,
  },
}, null, 2);

const exceptionMiddleware = N => `using Microsoft.AspNetCore.Mvc;
using ${N}.Domain.Exceptions;

namespace ${N}.API.Middleware;

/// <summary>
/// Global exception handler. Converts domain exceptions to ProblemDetails (RFC 7807).
/// Never use try/catch directly in endpoints — let this handle everything.
/// </summary>
public class ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (NotFoundException ex)     { await Write(ctx, 404, "Not Found", ex.Message); }
        catch (BusinessRuleException ex) { await Write(ctx, 422, "Business Rule Violation", ex.Message); }
        catch (DomainException ex)       { await Write(ctx, 400, "Domain Error", ex.Message); }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled exception");
            await Write(ctx, 500, "Internal Server Error", "An unexpected error occurred.");
        }
    }

    static async Task Write(HttpContext ctx, int status, string title, string detail)
    {
        ctx.Response.StatusCode = status;
        ctx.Response.ContentType = "application/problem+json";
        await ctx.Response.WriteAsJsonAsync(
            new ProblemDetails { Status = status, Title = title, Detail = detail });
    }
}`;

const docsReadme = name => `# docs — ${name}-backend

This folder is the **source of truth** for the backend agent.

## Structure

\`\`\`
docs/
├── user-stories/     ← User stories (.md files, one per story)
├── api-contracts/    ← OpenAPI specs or endpoint descriptions
└── README.md
\`\`\`

## Adding a user story

Create a \`.md\` file in \`user-stories/\` following the frontmatter format:

\`\`\`markdown
---
id: US-001
title: User registration
layer: backend
priority: high
status: pending
---
\`\`\`

Then run from the project root:

\`\`\`bash
npx agent-docs
\`\`\`

This injects all stories into \`.cursorrules\` and \`CLAUDE.md\`.
`;

const exampleStory = () => `---
id: US-001
title: User registration
layer: backend
priority: high
status: pending
---

# US-001 — User registration

**As** an unauthenticated user
**I want** to create an account with email and password
**So that** I can access protected features

## Acceptance criteria

- [ ] \`POST /api/auth/register\` accepts \`{ email, password, name }\`
- [ ] Password is hashed with IPasswordHasher<T> before persisting
- [ ] If email already exists, returns \`422 Unprocessable Entity\`
- [ ] If validation fails, returns \`400 Bad Request\` with field errors
- [ ] On success, returns \`201 Created\` with \`{ userId }\`

## Technical notes

- Entity: \`User\` in Domain layer
- Use case: \`RegisterUserCommand\` in Application layer
- Repository: \`IUserRepository\`
- Validator: \`RegisterUserValidator\` (FluentValidation)
`;

const gitignore = () => `bin/
obj/
.vs/
*.user
appsettings.Development.json
*.env
.env`;

const readme = (config, N) => `# ${config.projectName}-backend

Generated by **lv-agents** — Clean Architecture in .NET 10.

## Quick start

\`\`\`bash
dotnet restore
dotnet run --project src/${N}.API
\`\`\`

## Agent

${config.aiTools.includes('cursor') ? '- **Cursor**: open this folder — `.cursorrules` activates automatically' : ''}
${config.aiTools.includes('claude') ? '- **Claude Projects**: paste `CLAUDE.md` into Project Instructions' : ''}

## User stories

Add \`.md\` files to \`docs/user-stories/\` and run:

\`\`\`bash
npx agent-docs
\`\`\`
`;
