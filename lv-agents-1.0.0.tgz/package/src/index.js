#!/usr/bin/env node
import prompts from 'prompts';
import chalk from 'chalk';
import ora from 'ora';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateBackend } from './generators/backend.js';
import { generateFrontend } from './generators/frontend.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

console.log(`
${chalk.bold.hex('#7c3aed')('┌──────────────────────────────────────┐')}
${chalk.bold.hex('#7c3aed')('│')}  ${chalk.bold.white('lv-agents')} ${chalk.dim('— AI Agent Initializer')}    ${chalk.bold.hex('#7c3aed')('│')}
${chalk.bold.hex('#7c3aed')('│')}  ${chalk.dim('Backend (.NET 10) + Frontend (React)')}  ${chalk.bold.hex('#7c3aed')('│')}
${chalk.bold.hex('#7c3aed')('└──────────────────────────────────────┘')}
`);

const onCancel = () => { console.log(chalk.yellow('\nCancelled.')); process.exit(0); };

// ── Only ask what is truly needed ─────────────────────────────────────────────
const config = await prompts([
  {
    type: 'text',
    name: 'projectName',
    message: 'Project name',
    initial: 'my-project',
    validate: v => /^[a-z0-9-]+$/.test(v) || 'Lowercase letters, numbers and hyphens only',
  },
  {
    type: 'text',
    name: 'businessDescription',
    message: 'Describe the business / what the site is for (for UX/UI design)',
    hint: 'e.g. Online plant nursery selling indoor plants to urban millennials',
    initial: '',
  },
  {
    type: 'multiselect',
    name: 'aiTools',
    message: 'AI tools to configure (space to select)',
    choices: [
      { title: 'Cursor (.cursorrules)',        value: 'cursor', selected: true },
      { title: 'Claude Projects (CLAUDE.md)',  value: 'claude', selected: true },
    ],
    min: 1,
  },
], { onCancel });

// ── Confirm ───────────────────────────────────────────────────────────────────
const tools = Array.isArray(config.aiTools)
  ? config.aiTools.join(', ')
  : String(config.aiTools ?? '');

console.log(`
${chalk.bold('Summary')}
  Project  : ${chalk.cyan(config.projectName)}
  Business : ${chalk.cyan(config.businessDescription || '— (run /design later to define it)')}
  AI tools : ${chalk.cyan(tools)}

  Will create:
    ${chalk.cyan(`${config.projectName}-backend/`)}   (.NET 10 · Clean Architecture)
    ${chalk.cyan(`${config.projectName}-frontend/`)}  (React 18 · Vite · TypeScript)
`);

const { confirm } = await prompts({
  type: 'confirm',
  name: 'confirm',
  message: 'Generate projects?',
  initial: true,
}, { onCancel });

if (!confirm) { console.log(chalk.yellow('Cancelled.')); process.exit(0); }

// ── Generate ──────────────────────────────────────────────────────────────────
console.log('');
const spinner = ora({ text: 'Generating backend...', color: 'cyan' }).start();

try {
  await generateBackend(config, __dirname);
  spinner.succeed(chalk.green(`Backend ready: ${config.projectName}-backend/`));

  spinner.start('Generating frontend...');
  await generateFrontend(config, __dirname);
  spinner.succeed(chalk.green(`Frontend ready: ${config.projectName}-frontend/`));

  console.log(`
${chalk.bold.green('✓ Done!')}

${chalk.bold('Next steps')}

  ${chalk.bold('1. Configure Claude Projects')} ${chalk.dim('(one time per project)')}

     Backend agent:
       Open   ${chalk.cyan(`${config.projectName}-backend/CLAUDE.md`)}
       Create a Claude Project → paste content into "Project instructions"

     Frontend agent:
       Open   ${chalk.cyan(`${config.projectName}-frontend/CLAUDE.md`)}
       Create a Claude Project → paste content into "Project instructions"

  ${chalk.bold('2. Use the agents in Claude')}

     Backend project chat:
       ${chalk.cyan('/backend <task>')}    ${chalk.dim('e.g. /backend generate user registration')}
       ${chalk.cyan('/domain <entity>')}   ${chalk.dim('e.g. /domain Product')}
       ${chalk.cyan('/endpoint POST /api/products')}
       ${chalk.cyan('/docs')}              ${chalk.dim('reads your user stories')}

     Frontend project chat:
       ${chalk.cyan('/frontend <task>')}   ${chalk.dim('e.g. /frontend generate login page')}
       ${chalk.cyan('/component <name>')}  ${chalk.dim('e.g. /component ProductCard')}
       ${chalk.cyan('/feature <name>')}    ${chalk.dim('e.g. /feature catalog')}
       ${chalk.cyan('/docs')}              ${chalk.dim('reads your user stories')}

  ${chalk.bold('3. Use with Cursor')}

     The ${chalk.cyan('.cursorrules')} file is already in each repo root.
     Open the folder in Cursor — the agent activates automatically.

  ${chalk.bold('4. Install UX/UI skills')} ${chalk.dim('(frontend — run once)')}

     ${chalk.cyan(`cd ${config.projectName}-frontend`)}
     ${chalk.cyan('node install-skills.js')}

     Or individually:
     ${chalk.cyan('npx skills add emilkowalski/skill')}
     ${chalk.cyan('npx impeccable install')}
     ${chalk.cyan('npx skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"')}

     Check ${chalk.cyan('SKILLS.md')} to see which ones installed automatically.

  ${chalk.bold('5. Add user stories')}

     Create .md files in ${chalk.cyan('docs/user-stories/')} of each project.
     Then run: ${chalk.cyan('npx agent-docs')} ${chalk.dim('(or agent-docs --all from parent folder)')}

${chalk.dim('────────────────────────────────────────')}
`);
} catch (err) {
  spinner.fail(chalk.red('Error during generation'));
  console.error(err);
  process.exit(1);
}
