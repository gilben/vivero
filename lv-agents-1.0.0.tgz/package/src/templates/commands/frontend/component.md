Generate a complete UI component.

Usage: /component <ComponentName>

Deliver:
1. ComponentName.tsx with explicit TypeScript props interface
2. cva variants if the component has visual states
3. cn() for class composition
4. ComponentName.test.tsx with: renders correctly, loading state, error state
5. Any new types added to src/types/api.ts
