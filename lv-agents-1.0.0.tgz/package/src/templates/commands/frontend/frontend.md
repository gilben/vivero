Generate frontend code following the agent rules.

Usage: /frontend <task description>

Rules:
- TypeScript strict mode always
- CSS variables only, never hardcoded hex
- Radix UI for all interactive components
- motion for all animations
- sonner for toasts (Toaster already in App.tsx)
- cn() for all class composition
- cva for all variant components
- lucide-react as only icon source
- Deliver: component + hook + test + file list
