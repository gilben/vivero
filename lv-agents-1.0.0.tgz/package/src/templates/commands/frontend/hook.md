Generate a custom React hook.

Usage: /hook <hookName>

Rules:
- useQuery for reads — never useEffect + useState for fetching
- useMutation for writes
- All HTTP through apiClient.ts
- Include loading, error, and success states
