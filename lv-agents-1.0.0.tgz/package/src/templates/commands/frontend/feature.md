Generate a complete feature module.

Usage: /feature <featureName>

Deliver:
1. src/features/<featureName>/components/ — all components
2. src/features/<featureName>/hooks/ — useQuery or useMutation hooks
3. src/features/<featureName>/types/ — feature-specific types
4. Page component in src/pages/
5. Route registration in App.tsx
