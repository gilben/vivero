Generate a validated form component.

Usage: /form <FormName>

Deliver:
1. FormName.tsx using React Hook Form + Zod
2. Zod schema with all validation rules
3. Inline field-level error messages with role="alert"
4. Submit button with isLoading spinner (Loader2 from lucide-react)
5. useMutation hook for the submit action
6. sonner toast on success and error
