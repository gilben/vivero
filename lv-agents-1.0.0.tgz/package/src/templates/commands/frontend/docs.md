Read user stories and build a work queue.

Usage: /docs

Steps:
1. Ask user to paste content of docs/user-stories/ if not in context
2. Parse frontmatter: id, title, layer, priority, status
3. Filter: layer = frontend or both
4. Sort: high → medium → low
5. Present the queue and ask which story to start with
