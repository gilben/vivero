Generate backend code following Clean Architecture rules.

Usage: /backend <task description>

Rules:
- Always implement all four layers: Domain, Application, Infrastructure, API
- Use Minimal APIs, never Controllers
- Return IResult via Results.*
- All errors through ExceptionMiddleware → ProblemDetails
- Deliver: entity + interface + use case + DTO + validator + repository + endpoint
- End with a checklist of every file created
