Generate repository interface and implementation.

Usage: /repository <EntityName>

Deliver:
1. IEntityRepository interface in Domain/Interfaces/ (no EF/Mongo references)
2. Concrete implementation in Infrastructure/Repositories/
3. DI registration in Program.cs
