Generate a Minimal API endpoint.

Usage: /endpoint <HTTP_METHOD> <route>
Example: /endpoint POST /api/products

Deliver:
1. Endpoint method using Results.*
2. Route group registration
3. Authorization attribute if route is protected
4. Addition to Program.cs
