Generate a Command or Query use case.

Usage: /usecase <UseCaseName>

Deliver:
1. Command or Query record in Application/UseCases/
2. Handler class
3. Input and Output DTOs in Application/DTOs/
4. FluentValidation validator in Application/Validators/
