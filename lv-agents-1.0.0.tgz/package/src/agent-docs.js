#!/usr/bin/env node
/**
 * agent-docs
 * Parses docs/user-stories/*.md and injects context into .cursorrules and CLAUDE.md
 *
 * Usage:
 *   npx agent-docs              — update current repo
 *   npx agent-docs --all        — update all *-backend and *-frontend folders
 *   npx agent-docs --path ./x   — update a specific folder
 */
import fs from 'fs-extra';
import path from 'path';
import matter from 'gray-matter';
import chalk from 'chalk';
import ora from 'ora';

const START = '<!-- AGENT_DOCS_START -->';
const END   = '<!-- AGENT_DOCS_END -->';

const args = process.argv.slice(2);
const allFlag  = args.includes('--all');
const pathIdx  = args.indexOf('--path');
const pathFlag = pathIdx !== -1 ? path.resolve(args[pathIdx + 1]) : null;

const targets = [];

if (allFlag) {
  const entries = await fs.readdir(process.cwd(), { withFileTypes: true });
  for (const e of entries) {
    if (e.isDirectory() && (e.name.endsWith('-backend') || e.name.endsWith('-frontend'))) {
      targets.push(path.join(process.cwd(), e.name));
    }
  }
  if (!targets.length) {
    console.log(chalk.yellow('No *-backend or *-frontend folders found in current directory.'));
    process.exit(0);
  }
} else if (pathFlag) {
  targets.push(pathFlag);
} else {
  targets.push(process.cwd());
}

for (const target of targets) {
  const spinner = ora({ text: `Processing ${path.basename(target)}...`, color: 'cyan' }).start();
  const docsDir = path.join(target, 'docs', 'user-stories');

  if (!await fs.pathExists(docsDir)) {
    spinner.warn(chalk.yellow(`${path.basename(target)}: docs/user-stories/ not found — skipped`));
    continue;
  }

  const files = (await fs.readdir(docsDir)).filter(f => f.endsWith('.md')).sort();

  if (!files.length) {
    spinner.info(chalk.dim(`${path.basename(target)}: no stories yet`));
    continue;
  }

  const stories = [];
  for (const file of files) {
    const raw = await fs.readFile(path.join(docsDir, file), 'utf8');
    const { data: fm, content } = matter(raw);
    stories.push({ file, fm, content: content.trim() });
  }

  // Build context block
  const block = [
    `Updated: ${new Date().toISOString()}`,
    `Total stories: ${stories.length}`,
    ``,
    `| ID | Title | Layer | Priority | Status |`,
    `|---|---|---|---|---|`,
    ...stories.map(s => `| ${s.fm.id ?? '—'} | ${s.fm.title ?? '—'} | ${s.fm.layer ?? '—'} | ${s.fm.priority ?? '—'} | ${s.fm.status ?? '—'} |`),
    ``,
    ...stories.flatMap(s => [
      `## ${s.fm.id ?? s.file} — ${s.fm.title ?? 'Untitled'}`,
      s.fm.layer    ? `**Layer:** ${s.fm.layer}`    : '',
      s.fm.priority ? `**Priority:** ${s.fm.priority}` : '',
      s.fm.status   ? `**Status:** ${s.fm.status}`  : '',
      ``,
      s.content,
      ``,
      `---`,
      ``,
    ].filter(Boolean)),
  ].join('\n');

  // Inject into agent files
  const agentFiles = ['.cursorrules', 'CLAUDE.md']
    .map(f => path.join(target, f))
    .filter(f => fs.existsSync(f));

  let updated = 0;
  for (const file of agentFiles) {
    let content = await fs.readFile(file, 'utf8');
    const si = content.indexOf(START);
    const ei = content.indexOf(END);
    if (si === -1 || ei === -1) continue;
    content = content.slice(0, si + START.length) + '\n' + block + '\n' + content.slice(ei);
    await fs.writeFile(file, content, 'utf8');
    updated++;
  }

  if (updated > 0) {
    spinner.succeed(chalk.green(
      `${path.basename(target)}: ${stories.length} story/stories → ${updated} agent file(s) updated`
    ));
  } else {
    spinner.warn(chalk.yellow(`${path.basename(target)}: no agent files found (.cursorrules / CLAUDE.md)`));
  }
}
