# lv-agents — Guía de uso paso a paso

CLI que genera dos proyectos con "agentes" de IA ya configurados:

- **`<nombre>-backend/`** — .NET 10, Clean Architecture
- **`<nombre>-frontend/`** — React 18 + Vite + TypeScript

Cada proyecto incluye un `CLAUDE.md` / `.cursorrules` (las reglas del agente),
comandos slash y un flujo de historias de usuario.

> **Ruta de la copia oficial del CLI:**
> `C:\Proyectos\agentes\Agente\lv-agents-1.0.0\package`
> Todos los cambios al comportamiento del agente se hacen aquí.

---

## Índice

1. [Concepto clave: código fuente vs. comando instalado](#1-concepto-clave)
2. [Instalar / actualizar el CLI global](#2-instalar--actualizar-el-cli-global)
3. [Generar un proyecto nuevo](#3-generar-un-proyecto-nuevo)
4. [Activar el agente (Claude Code / Cursor)](#4-activar-el-agente)
5. [Trabajar con historias de usuario](#5-trabajar-con-historias-de-usuario)
6. [Instalar las skills de UX/UI](#6-instalar-las-skills-de-uxui)
7. [Implementar una historia](#7-implementar-una-historia)
8. [Solución de problemas](#8-solución-de-problemas)

---

## 1. Concepto clave

Hay dos cosas distintas:

- **El código fuente** (esta carpeta `package/`) — lo que editas para cambiar
  cómo se comporta el agente.
- **El comando instalado** (`lv-agents`) — una copia congelada que se usa
  cuando escribes `lv-agents` en la terminal.

**Editar el código fuente NO cambia el comando instalado.** Cada vez que
modifiques las reglas del agente, tienes que reinstalar el global (paso 2)
para que los proyectos nuevos hereden los cambios.

---

## 2. Instalar / actualizar el CLI global

Ejecuta esto **cada vez que cambies el código** del agente (o la primera vez):

```powershell
cd C:\Proyectos\agentes\Agente\lv-agents-1.0.0\package
npm install          # solo la primera vez (instala dependencias)
npm pack             # crea lv-agents-1.0.0.tgz (la "fotocopia" instalable)
npm install -g lv-agents-1.0.0.tgz
```

- `npm pack` **no toca el sistema**, solo crea el archivo `.tgz`.
- `npm install -g` reemplaza el comando `lv-agents` viejo por el nuevo.

**Verificar que quedó bien:**

```powershell
npm ls -g lv-agents        # debe listar lv-agents@1.0.0
lv-agents --help           # o simplemente: lv-agents
```

---

## 3. Generar un proyecto nuevo

> ⚠️ **Hazlo desde una carpeta de trabajo VACÍA**, nunca dentro de la carpeta
> `package/` del CLI. El generador crea las carpetas en el directorio actual.

```powershell
cd C:\Proyectos\agentes\Proyectos        # tu carpeta de trabajo
lv-agents
```

Responde las preguntas:

1. **Project name** — minúsculas, números y guiones (ej. `pj5`)
2. **AI tools** — marca Cursor y/o Claude Projects (barra espaciadora)

Al confirmar se crean:

```
pj5-backend/     (.NET 10 · Clean Architecture)
pj5-frontend/    (React 18 · Vite · TypeScript)
```

> El CLI solo **escribe archivos**. No corre `dotnet` ni `npm install` por ti.
> Para levantar cada proyecto:
> - Backend:  `dotnet run --project src/Pj5.API`
> - Frontend: `npm install` y luego `npm run dev`

---

## 4. Activar el agente

El agente **no es un servicio que corre** — son las reglas del `CLAUDE.md` /
`.cursorrules` que cargas en tu herramienta de IA.

### Opción A — Claude Code (terminal / extensión VS Code)

Ábrelo **parado exactamente en la carpeta del proyecto**:

```powershell
cd C:\Proyectos\agentes\Proyectos\pj5-frontend
claude
```

- El `CLAUDE.md` se carga automáticamente.
- Los comandos slash salen de `.claude/commands/`. Escribe `/` para verlos.
- Si generaste el proyecto mientras `claude` ya estaba abierto, **reinícialo**
  (sal con `/exit` y vuelve a entrar) para que cargue los comandos.

### Opción B — Cursor

Abre la carpeta del proyecto en Cursor. El `.cursorrules` se activa solo.

### Opción C — Claude Projects (claude.ai web/app)

No hay slash commands nativos. Copia **todo** el contenido de `CLAUDE.md` y
pégalo en las *Project Instructions* del Project. Luego escribe `/docs`,
`/feature`, etc. como texto normal (el modelo los interpreta por las reglas).

---

## 5. Trabajar con historias de usuario

### 5.1 Escribir la historia

Crea un `.md` en `docs/user-stories/` del proyecto. El frontmatter debe
**abrir y cerrar** con `---` (el `---` de la primera línea es obligatorio):

```markdown
---
id: ST-001
title: Pantalla de login
layer: frontend
priority: high
status: pending
---

# ST-001 — Pantalla de login

**Como** usuario **quiero** ... **para** ...

## Criterios de aceptación
- [ ] ...
```

Valores de `layer`: `frontend`, `backend` o `both`.
Valores de `priority`: `high`, `medium`, `low`.

### 5.2 Inyectar las historias en el agente

`agent-docs` lee todos los `.md` de `docs/user-stories/` y los inserta dentro
del `CLAUDE.md` / `.cursorrules` (entre los marcadores `AGENT_DOCS_START/END`).

Desde la carpeta del proyecto:

```powershell
cd C:\Proyectos\agentes\Proyectos\pj5-frontend
npx agent-docs
```

Para actualizar backend y frontend a la vez, desde la carpeta que los contiene:

```powershell
cd C:\Proyectos\agentes\Proyectos
npx agent-docs --all
```

Salida esperada:

```
✔ pj5-frontend: 1 story/stories → 2 agent file(s) updated
```

### 5.3 Usar `/docs` en el agente

En Claude Code / Cursor, escribe:

```
/docs
```

El agente parsea el frontmatter, filtra por `layer`, ordena por prioridad
(high → low) y arma la cola de trabajo.

### 5.4 Flujo de estados

- Al terminar una historia, cambia su frontmatter a `status: in-review`.
- Vuelve a correr `npx agent-docs` para refrescar la tabla.
- Solo QA/PO mueve una historia a `done` (según su DoD).

---

## 6. Instalar las skills de UX/UI

El frontend usa tres skills de diseño. El generador **intenta** instalarlas
automáticamente; si algo falla, reinstálalas manualmente:

```powershell
cd C:\Proyectos\agentes\Proyectos\pj5-frontend
node install-skills.js
```

El script verifica en disco que exista el `SKILL.md` de cada skill y reporta
`✓`/`✗` real. Revisa `SKILLS.md` para ver el estado.

**Windows — error `'unzip' is not recognized`** (al instalar impeccable):
crea un shim `unzip.cmd` en una carpeta del PATH con este contenido:

```bat
@echo off
mkdir %4 2>nul
tar -xf %2 -C %4
```

Luego reintenta `node install-skills.js`.

---

## 7. Implementar una historia

Con la historia ya inyectada (paso 5), pídele al agente el comando adecuado:

| Alcance | Comando | Ejemplo |
|---|---|---|
| Módulo completo | `/feature <nombre>` | `/feature auth — implementa ST-001` |
| Un formulario | `/form <nombre>` | `/form Login` |
| Un componente | `/component <nombre>` | `/component ProductCard` |
| Un hook | `/hook <nombre>` | `/hook useProducts` |
| Una página | `/page <nombre>` | `/page Dashboard` |
| Tarea libre | `/frontend <tarea>` | `/frontend agrega dark mode toggle` |

Para historias grandes (login + recuperación + notificaciones), usa
`/feature`. El agente entrega componentes + hooks + tipos + tests + rutas y
cierra con la lista de archivos creados.

---

## 8. Solución de problemas

| Síntoma | Causa | Solución |
|---|---|---|
| El proyecto nuevo sale con reglas viejas | El global no se reinstaló tras editar el código | Repite el **paso 2** |
| `Cannot find module ...\install-skills.js` | Lo corriste desde la carpeta equivocada | `cd` a `<proyecto>-frontend` y córrelo ahí |
| La tabla de historias sale con `—` | Al `.md` le falta el `---` de apertura del frontmatter | Agrega `---` en la primera línea y re-corre `npx agent-docs` |
| `/docs` no aparece en Claude Code | Abriste `claude` desde otra carpeta, o no reiniciaste | `cd` a la carpeta del proyecto, reinicia `claude` |
| `npx agent-docs` descarga un paquete ajeno | `lv-agents` no está instalado | Instala el global (**paso 2**) |
| Dark mode no aplica | (Ya corregido en la base) `darkMode` desalineado con los tokens | Regenera desde el CLI actualizado |

---

## Resumen del ciclo completo

```
Editar código del agente
        │
        ▼
npm pack + npm install -g          ← paso 2 (cada vez que editas)
        │
        ▼
lv-agents  (en carpeta vacía)      ← genera <nombre>-backend/ y -frontend/
        │
        ▼
Escribir historias en docs/user-stories/  →  npx agent-docs
        │
        ▼
claude  (en la carpeta del proyecto)  →  /docs  →  /feature ...
```
